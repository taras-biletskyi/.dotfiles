# Welcome

Welcome to my userspace.

There's nothing really outstanding here, except the [Ocean Dream](readme_ocean_dream.md)
animation I made. 

A lot of the code for my wrappers/keymaps came from other users. 

I will probably update this with more in-depth information later. 
