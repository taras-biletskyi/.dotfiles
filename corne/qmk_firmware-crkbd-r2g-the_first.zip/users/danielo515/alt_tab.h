#pragma once
#include "quantum.h"

bool process_alt_tab(uint16_t keycode, keyrecord_t *record);
