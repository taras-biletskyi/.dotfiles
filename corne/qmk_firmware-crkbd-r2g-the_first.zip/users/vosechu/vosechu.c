#include "vosechu.h"

// void my_custom_function(void) {

// }

// [DV] =  { /* ================================================== DVORAK ============================================================ */
//   { KC_1, KC_A, KC_B, KC_C, KC_D, KC_E, _______ , KC_G, KC_H, KC_J, KC_K, KC_L, KC_M },
//   { KC_2, KC_A, KC_B, KC_C, KC_D, KC_E, _______ , KC_G, KC_H, KC_J, KC_K, KC_L, KC_M },
//   { KC_3, KC_A, KC_B, KC_C, KC_D, KC_E, _______ , KC_G, KC_H, KC_J, KC_K, KC_L, KC_M },
//   { KC_4, KC_A, KC_B, KC_C, KC_D, KC_E, KC_F    , KC_G, KC_H, KC_J, KC_K, KC_L, KC_M },
//   { KC_5, KC_A, KC_B, KC_C, KC_D, KC_E, KC_F    , KC_G, KC_H, KC_J, KC_K, KC_L, KC_M }
// },

// bool process_record_user(uint16_t keycode, keyrecord_t *record) {
//   if (record->event.pressed) {
//     // These also need to be defined in the header file
//     switch(keycode) {
//       case PAWFIVE:
//         SEND_STRING(":pawfive:");
//         return false;
//     }
//   }
//   return true;
// };
