#pragma once

#define TAPPING_TERM 600 // ms
#define PERMISSIVE_HOLD
#undef RGBLIGHT_HUE_STEP
#define RGBLIGHT_HUE_STEP 8
