# brandonschlack's 75_ansi layout

This is my preferred 75% layout.

It is currently used on:

* [KBD75](https://github.com/qmk/qmk_firmware/tree/master/keyboards/kbdfans/kbd75)
